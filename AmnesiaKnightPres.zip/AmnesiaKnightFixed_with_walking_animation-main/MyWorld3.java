import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class MyWorld3 extends World
{

    /**
     * Constructor for objects of class MyWorld3.
     */
    public MyWorld3()
    {
        super(600, 400, 1);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare() { 
        Knight knight = new Knight(this); 
        addObject(knight, 20, 250);    
        MiniBoss miniBoss = new MiniBoss();
        addObject(miniBoss,384,244);
    }
}

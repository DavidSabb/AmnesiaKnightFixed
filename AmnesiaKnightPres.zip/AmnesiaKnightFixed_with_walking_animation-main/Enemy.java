import lang.stride.*;
import java.util.*;
import greenfoot.*;

public class Enemy extends Actor {
    private int health = 3;
    private int moveCooldown = 0;
    private int moveCooldownMax = 50; 

    public Enemy() {
        turn(Greenfoot.getRandomNumber(360));
    }

    public void act() {
        moveTowardsKnight();
        hitByKnight();
        checkCollision();
    }

    public void moveTowardsKnight() {
        // Get a reference to the Knight
        Knight knight = (Knight) getWorld().getObjects(Knight.class).get(0);
        
        // Calculate direction towards the Knight
        int dx = knight.getX() - getX();
        int dy = knight.getY() - getY();
        
        // Move towards the Knight
        if (dx != 0 || dy != 0) {
            int dist = (int) Math.sqrt(dx * dx + dy * dy);
            setLocation(getX() + dx * 2 / dist, getY() + dy * 2 / dist);
        }
    }

    public void attack() {
        Actor knight = getOneIntersectingObject(Knight.class);
        if (knight != null) {
            World world = getWorld();
            world.removeObject(knight);
        }
    }

    public void hitByKnight() {
        Actor slash = getOneIntersectingObject(PlayerSlash.class);
        if (slash != null) {
            health--;
            getWorld().removeObject(slash);
        }
        if (health < 1) {
            getWorld().removeObject(this);
        }
    }


    public void checkCollision() {
    if (health > 1) {
        if (getX() < 50) {
            setLocation(50, getY()); // Adjust X position to avoid getting stuck at the left edge
        }
        if (getY() < 140) {
            setLocation(getX(), 140); // Adjust Y position to avoid getting stuck at the top edge
        }
        if (getX() > getWorld().getWidth() - 50) {
            setLocation(getWorld().getWidth() - 50, getY()); // Adjust X position to avoid getting stuck at the right edge
        }
        if (getY() > getWorld().getHeight() - 50) {
            setLocation(getX(), getWorld().getHeight() - 50); // Adjust Y position to avoid getting stuck at the bottom edge
        }
    }
    }
}


import greenfoot.*;

public class MiniBoss extends Actor {
    private int health = 10; // Total health of the mini-boss
    private int currentStage = 1; // Current stage of the mini-boss
    private int evadeCooldown = 0; // Cooldown for evading player
    private int slashCooldown = 0; // Cooldown for using slashes
    private int attackTimer = 300; // Timer for the attack

    public MiniBoss() {
        // Set initial appearance and behavior for stage 1
        // add image later setImage("phase one");
    }

    public void act() {
        // Check if mini-boss has been defeated
        if (health <= 0) {
            defeat();
            return;
        }

        // Check if mini-boss should transition to stage 2
        if (currentStage == 1 && health <= 5) {
            transitionToStage2();
            return;
        }

        // Perform actions based on the current stage
        if (currentStage == 1) {
            stage1Behavior();
        } else if (currentStage == 2) {
            stage2Behavior();
        }
        
        // Check for collision with player's slashes
        checkSlashCollision();
        
        // Display MiniBoss's health
        displayHealth();
    }

    private void stage1Behavior() {
        // Evade the player if cooldown is over
        if (evadeCooldown <= 0) {
            Actor knight = getWorld().getObjects(Knight.class).get(0);
            if (knight != null) {
                turnTowards(knight.getX(), knight.getY());
                move(-4); // Move away from the player
                evadeCooldown = 50; // Set evade cooldown
            }
        } else {
            evadeCooldown--; // Decrease evade cooldown
        }

        // Use far-range slashes if cooldown is over
        if (slashCooldown <= 0) {
            fireFarRangeSlash();
            slashCooldown = 150; // Set slash cooldown
        } else {
            slashCooldown--; // Decrease slash cooldown
        }
    }

    private void stage2Behavior() {
        // Move towards the player
        Actor knight = getWorld().getObjects(Knight.class).get(0);
        if (knight != null) {
            turnTowards(knight.getX(), knight.getY());
            move(1); // Move towards the player at a moderate speed
        }

        // Perform the attack every 5 seconds
        if (attackTimer <= 0) {
            performCardinalAttack();
            attackTimer = 500; // Reset the timer for the next attack
        } else {
            attackTimer--; // Decrease the attack timer
        }

        // Use close-range slashes if cooldown is over
        if (slashCooldown <= 0) {
            fireCloseRangeSlash();
            slashCooldown = 50; // Set slash cooldown
        } else {
            slashCooldown--; // Decrease slash cooldown
        }
    }

    private void transitionToStage2() {
        // Transition mini-boss to stage 2
        currentStage = 2;
        // image to be added setImage("phase 2");
        health = 10; // Reset health for stage 2
    }

    private void defeat() {
        getWorld().removeObject(this);
        // Make the player gain another ability in the future after this event is triggered
    }

    private void fireFarRangeSlash() {
        // Create a far-range slash and add it to the world
        FarRangeSlash farRangeSlash = new FarRangeSlash();
        getWorld().addObject(farRangeSlash, getX(), getY());
        farRangeSlash.setRotation(getRotation()); // Set the rotation of the slash
    }

    private void fireCloseRangeSlash() {
        // Create a close-range slash and add it to the world
        BossSlash slash = new BossSlash();
        getWorld().addObject(slash, getX(), getY());
        slash.setRotation(getRotation()); // Set the rotation of the slash
    }
    
    private void checkSlashCollision() {
        // Get all slashes in the world
        java.util.List<PlayerSlash> playerSlashes = getIntersectingObjects(PlayerSlash.class);
        
        // Check each slash for collision
        for (PlayerSlash slash : playerSlashes) {
            // Reduce mini-boss health if hit by player's slash
            health--;
            // Remove the slash from the world
            getWorld().removeObject(slash);
        }
    }
    
    private void displayHealth() {
        World world = getWorld();
        if (world != null) {
            // Remove the previous health display
            world.removeObjects(world.getObjects(HealthText.class));

            // Display MiniBoss's health above its image if health is greater than zero
            if (health > 0) {
                world.addObject(new HealthText("Health: " + health), getX(), getY() - getImage().getHeight() / 2 - 20);
            }
        }
    }

    private void performCardinalAttack() {
        // Send out slashes in all cardinal directions twice
        for (int i = 0; i < 2; i++) {
            for (int angle = 0; angle < 360; angle += 90) {
                sendSlash(angle);
            }
        }
    }

    private void sendSlash(int angle) {
        // Create a new slash and add it to the world
        BossSlash slash = new BossSlash();
        getWorld().addObject(slash, getX(), getY());
        slash.setRotation(angle); // Set the rotation of the slash
    }
}

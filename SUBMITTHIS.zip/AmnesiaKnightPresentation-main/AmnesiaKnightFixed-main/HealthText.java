import greenfoot.*;

public class HealthText extends Actor {
    public HealthText(String text) {
        GreenfootImage image = new GreenfootImage(text, 20, Color.WHITE, new Color(0, 0, 0, 0));
        setImage(image);
    }
    
    public void act() {
        // Empty act method, HealthText objects do not perform any actions
    }
}